@file:Suppress("DEPRECATION")

package com.nosensor.dialer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService

/**
 * This service is the whole reason the proximity sensor is off.
 * Android only turns the screen off near your ear when the in-call UI
 * acquires a PROXIMITY_SCREEN_OFF wake lock. This app never does.
 */
class CallService : InCallService() {

    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        CallManager.service = this
        CallManager.add(call)
        showUi(call)
    }

    override fun onCallRemoved(call: Call) {
        super.onCallRemoved(call)
        CallManager.remove(call)
        getSystemService(NotificationManager::class.java).cancel(1)
    }

    override fun onCallAudioStateChanged(audioState: CallAudioState) {
        CallManager.muted = audioState.isMuted
        CallManager.speaker = audioState.route == CallAudioState.ROUTE_SPEAKER
    }

    private fun showUi(call: Call) {
        val intent = Intent(this, InCallActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val pi = PendingIntent.getActivity(
            this, 0, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("calls", "Calls", NotificationManager.IMPORTANCE_HIGH)
        )
        val n = Notification.Builder(this, "calls")
            .setSmallIcon(android.R.drawable.sym_action_call)
            .setContentTitle(CallManager.title)
            .setContentText("Call in progress")
            .setCategory(Notification.CATEGORY_CALL)
            .setOngoing(true)
            .setContentIntent(pi)
            .setFullScreenIntent(pi, true)
            .build()
        nm.notify(1, n)
        if (call.state != Call.STATE_RINGING) startActivity(intent)
    }
}
