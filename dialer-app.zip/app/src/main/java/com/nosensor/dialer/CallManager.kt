@file:Suppress("DEPRECATION")

package com.nosensor.dialer

import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.VideoProfile
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

object CallManager {
    var call by mutableStateOf<Call?>(null)
    var state by mutableIntStateOf(Call.STATE_NEW)
    var title by mutableStateOf("")
    var subtitle by mutableStateOf("")
    var muted by mutableStateOf(false)
    var speaker by mutableStateOf(false)
    var connectTime by mutableLongStateOf(0L)
    var service: CallService? = null

    private val callback = object : Call.Callback() {
        override fun onStateChanged(c: Call, s: Int) = update(c)
        override fun onDetailsChanged(c: Call, d: Call.Details) = update(c)
    }

    private fun update(c: Call) {
        state = c.state
        val num = c.details.handle?.schemeSpecificPart ?: ""
        val name = c.details.contactDisplayName
        if (!name.isNullOrBlank()) {
            title = name; subtitle = num
        } else {
            title = num.ifBlank { "Unknown" }; subtitle = ""
        }
        if (state == Call.STATE_ACTIVE && connectTime == 0L) connectTime = System.currentTimeMillis()
    }

    fun add(c: Call) {
        connectTime = 0L
        call = c
        c.registerCallback(callback)
        update(c)
    }

    fun remove(c: Call) {
        c.unregisterCallback(callback)
        if (call == c) {
            call = null
            state = Call.STATE_DISCONNECTED
        }
    }

    fun answer() { call?.answer(VideoProfile.STATE_AUDIO_ONLY) }
    fun hangup() {
        if (state == Call.STATE_RINGING) call?.reject(false, null) else call?.disconnect()
    }
    fun toggleMute() { service?.setMuted(!muted) }
    fun toggleSpeaker() {
        service?.setAudioRoute(
            if (speaker) CallAudioState.ROUTE_EARPIECE else CallAudioState.ROUTE_SPEAKER
        )
    }
}
