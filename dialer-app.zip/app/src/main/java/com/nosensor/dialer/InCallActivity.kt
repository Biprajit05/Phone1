package com.nosensor.dialer

import android.graphics.Color as AColor
import android.os.Bundle
import android.telecom.Call
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call as CallIcon
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

class InCallActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        // Keep the screen on while in a call. No proximity wake lock is ever taken.
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT)
        )
        setContent { AppTheme { InCallScreen { finish() } } }
    }
}

@Composable
fun InCallScreen(onFinish: () -> Unit) {
    val call = CallManager.call
    LaunchedEffect(call) {
        if (call == null) { delay(800); onFinish() }
    }
    val state = CallManager.state
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { delay(500); now = System.currentTimeMillis() } }

    val ringing = state == Call.STATE_RINGING
    val secs = ((now - CallManager.connectTime) / 1000).coerceAtLeast(0)
    val status = when (state) {
        Call.STATE_RINGING -> "Incoming call"
        Call.STATE_DIALING, Call.STATE_CONNECTING -> "Calling…"
        Call.STATE_ACTIVE -> "%02d:%02d".format(secs / 60, secs % 60)
        Call.STATE_HOLDING -> "On hold"
        Call.STATE_DISCONNECTING, Call.STATE_DISCONNECTED -> "Call ended"
        else -> ""
    }
    val initial = CallManager.title.firstOrNull()?.takeIf { it.isLetter() }?.uppercase()

    Column(
        Modifier.fillMaxSize().background(BgBrush)
            .statusBarsPadding().navigationBarsPadding().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.weight(0.7f))
        Box(
            Modifier.size(190.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.05f)),
            contentAlignment = Alignment.Center
        ) {
            Box(
                Modifier.size(136.dp).clip(CircleShape).background(
                    Brush.linearGradient(listOf(Color(0xFF6366F1), Color(0xFF8B5CF6)))
                ),
                contentAlignment = Alignment.Center
            ) {
                if (initial != null) {
                    Text(initial, color = Color.White, fontSize = 56.sp, fontWeight = FontWeight.Light)
                } else {
                    Icon(Icons.Default.Person, null, tint = Color.White, modifier = Modifier.size(64.dp))
                }
            }
        }
        Spacer(Modifier.height(32.dp))
        Text(
            CallManager.title, color = Color.White, fontSize = 32.sp,
            fontWeight = FontWeight.Medium, textAlign = TextAlign.Center, maxLines = 2
        )
        if (CallManager.subtitle.isNotEmpty()) {
            Spacer(Modifier.height(4.dp))
            Text(CallManager.subtitle, color = Color.White.copy(alpha = 0.6f), fontSize = 16.sp)
        }
        Spacer(Modifier.height(12.dp))
        Text(status, color = if (state == Call.STATE_ACTIVE) Green else Color.White.copy(alpha = 0.7f), fontSize = 18.sp)
        Spacer(Modifier.weight(1f))

        if (ringing) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                RoundBtn(Icons.Default.CallEnd, "Decline", Red, size = 80.dp) { CallManager.hangup() }
                RoundBtn(Icons.Default.CallIcon, "Answer", Green, size = 80.dp) { CallManager.answer() }
            }
        } else {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                RoundBtn(
                    if (CallManager.muted) Icons.Default.MicOff else Icons.Default.Mic, "Mute",
                    if (CallManager.muted) Color.White.copy(alpha = 0.9f) else Color.White.copy(alpha = 0.12f),
                    tint = if (CallManager.muted) Color.Black else Color.White
                ) { CallManager.toggleMute() }
                RoundBtn(
                    Icons.Default.VolumeUp, "Speaker",
                    if (CallManager.speaker) Color.White.copy(alpha = 0.9f) else Color.White.copy(alpha = 0.12f),
                    tint = if (CallManager.speaker) Color.Black else Color.White
                ) { CallManager.toggleSpeaker() }
            }
            Spacer(Modifier.height(36.dp))
            RoundBtn(Icons.Default.CallEnd, null, Red, size = 76.dp) { CallManager.hangup() }
        }
        Spacer(Modifier.height(24.dp))
    }
}
