package com.nosensor.dialer

import android.Manifest
import android.app.role.RoleManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color as AColor
import android.net.Uri
import android.os.Bundle
import android.provider.CallLog
import android.telecom.TelecomManager
import android.text.format.DateUtils
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.automirrored.filled.CallMade
import androidx.compose.material.icons.automirrored.filled.CallMissed
import androidx.compose.material.icons.automirrored.filled.CallReceived
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Dialpad
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT)
        )
        val initial = intent?.data?.schemeSpecificPart ?: ""
        setContent { AppTheme { App(initial) } }
    }
}

private fun hasPerms(ctx: Context) = listOf(
    Manifest.permission.CALL_PHONE, Manifest.permission.READ_CALL_LOG
).all { ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED }

fun placeCall(ctx: Context, number: String) {
    if (number.isBlank()) return
    try {
        ctx.getSystemService(TelecomManager::class.java)
            .placeCall(Uri.fromParts("tel", number, null), Bundle())
    } catch (_: SecurityException) {
    }
}

@Composable
fun App(initial: String) {
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    var number by remember { mutableStateOf(initial) }
    var granted by remember { mutableStateOf(hasPerms(ctx)) }

    val roleLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = hasPerms(ctx)
        val rm = ctx.getSystemService(RoleManager::class.java)
        if (!rm.isRoleHeld(RoleManager.ROLE_DIALER)) {
            roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_DIALER))
        }
    }
    LaunchedEffect(Unit) {
        permLauncher.launch(
            arrayOf(
                Manifest.permission.CALL_PHONE,
                Manifest.permission.READ_CALL_LOG,
                Manifest.permission.READ_CONTACTS,
                Manifest.permission.POST_NOTIFICATIONS
            )
        )
    }

    val navColors = NavigationBarItemDefaults.colors(
        selectedIconColor = Green, selectedTextColor = Green,
        indicatorColor = Color.White.copy(alpha = 0.08f),
        unselectedIconColor = Color.White.copy(alpha = 0.5f),
        unselectedTextColor = Color.White.copy(alpha = 0.5f)
    )

    Column(Modifier.fillMaxSize().background(BgBrush)) {
        Box(Modifier.weight(1f)) {
            if (tab == 0) {
                DialPad(number, { number = it }) { placeCall(ctx, number) }
            } else {
                Recents(granted) { placeCall(ctx, it) }
            }
        }
        NavigationBar(containerColor = Color.Transparent) {
            NavigationBarItem(
                selected = tab == 0, onClick = { tab = 0 }, colors = navColors,
                icon = { Icon(Icons.Default.Dialpad, null) }, label = { Text("Keypad") }
            )
            NavigationBarItem(
                selected = tab == 1, onClick = { tab = 1 }, colors = navColors,
                icon = { Icon(Icons.Default.History, null) }, label = { Text("Recents") }
            )
        }
    }
}

private val keys = listOf(
    listOf("1" to "", "2" to "ABC", "3" to "DEF"),
    listOf("4" to "GHI", "5" to "JKL", "6" to "MNO"),
    listOf("7" to "PQRS", "8" to "TUV", "9" to "WXYZ"),
    listOf("*" to "", "0" to "+", "#" to "")
)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun DialPad(number: String, onChange: (String) -> Unit, onCall: () -> Unit) {
    Column(
        Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 36.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.weight(1f))
        Text(
            if (number.isEmpty()) " " else number, color = Color.White,
            fontSize = if (number.length > 12) 30.sp else 42.sp,
            fontWeight = FontWeight.Light, maxLines = 1
        )
        Spacer(Modifier.height(28.dp))
        keys.forEach { row ->
            Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                row.forEach { (digit, letters) ->
                    Box(
                        Modifier.size(76.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.08f))
                            .clickable { onChange(number + digit) },
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(digit, color = Color.White, fontSize = 28.sp)
                            if (letters.isNotEmpty()) {
                                Text(letters, color = Color.White.copy(alpha = 0.5f), fontSize = 9.sp, letterSpacing = 1.sp)
                            }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Spacer(Modifier.size(76.dp))
            RoundBtn(Icons.Default.Call, null, Green, size = 76.dp, onClick = onCall)
            Box(
                Modifier.size(76.dp).clip(CircleShape).combinedClickable(
                    onClick = { onChange(number.dropLast(1)) },
                    onLongClick = { onChange("") }
                ),
                contentAlignment = Alignment.Center
            ) {
                if (number.isNotEmpty()) {
                    Icon(Icons.AutoMirrored.Filled.Backspace, null, tint = Color.White.copy(alpha = 0.7f))
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

data class Recent(val number: String, val name: String?, val type: Int, val date: Long)

private fun loadRecents(ctx: Context): List<Recent> {
    val out = mutableListOf<Recent>()
    try {
        ctx.contentResolver.query(
            CallLog.Calls.CONTENT_URI,
            arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE, CallLog.Calls.DATE),
            null, null, CallLog.Calls.DATE + " DESC"
        )?.use { c ->
            while (c.moveToNext() && out.size < 100) {
                out += Recent(c.getString(0) ?: "", c.getString(1), c.getInt(2), c.getLong(3))
            }
        }
    } catch (_: SecurityException) {
    }
    return out
}

@Composable
fun Recents(granted: Boolean, onCall: (String) -> Unit) {
    val ctx = LocalContext.current
    var list by remember { mutableStateOf(emptyList<Recent>()) }
    LaunchedEffect(granted) {
        list = withContext(Dispatchers.IO) { loadRecents(ctx) }
    }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Text(
            "Recents", color = Color.White, fontSize = 34.sp,
            fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(24.dp, 20.dp, 24.dp, 12.dp)
        )
        if (list.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    if (granted) "No recent calls" else "Allow call log access to see recents",
                    color = Color.White.copy(alpha = 0.5f)
                )
            }
        } else {
            LazyColumn {
                items(list) { r ->
                    val missed = r.type == CallLog.Calls.MISSED_TYPE || r.type == CallLog.Calls.REJECTED_TYPE
                    val title = r.name?.takeIf { it.isNotBlank() } ?: r.number.ifBlank { "Unknown" }
                    Row(
                        Modifier.fillMaxWidth().clickable { onCall(r.number) }.padding(horizontal = 24.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            Modifier.size(48.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.08f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                title.firstOrNull()?.takeIf { it.isLetter() }?.uppercase() ?: "#",
                                color = Color.White, fontSize = 20.sp
                            )
                        }
                        Column(Modifier.weight(1f).padding(start = 16.dp)) {
                            Text(title, color = if (missed) Red else Color.White, fontSize = 17.sp, maxLines = 1)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                val icon = when (r.type) {
                                    CallLog.Calls.OUTGOING_TYPE -> Icons.AutoMirrored.Filled.CallMade
                                    CallLog.Calls.INCOMING_TYPE -> Icons.AutoMirrored.Filled.CallReceived
                                    else -> Icons.AutoMirrored.Filled.CallMissed
                                }
                                Icon(icon, null, tint = if (missed) Red else Color.White.copy(alpha = 0.5f), modifier = Modifier.size(14.dp))
                                Text(
                                    "  " + DateUtils.getRelativeTimeSpanString(r.date, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS),
                                    color = Color.White.copy(alpha = 0.5f), fontSize = 13.sp
                                )
                            }
                        }
                        Icon(Icons.Default.Call, null, tint = Green, modifier = Modifier.size(22.dp))
                    }
                }
            }
        }
    }
}
